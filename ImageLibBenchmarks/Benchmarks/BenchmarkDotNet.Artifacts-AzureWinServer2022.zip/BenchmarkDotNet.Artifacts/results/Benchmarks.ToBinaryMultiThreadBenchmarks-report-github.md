```

BenchmarkDotNet v0.14.0, Windows 10 (10.0.20348.3270) (Hyper-V)
Intel Xeon Platinum 8171M CPU 2.60GHz, 1 CPU, 16 logical and 8 physical cores
.NET SDK 8.0.407
  [Host]     : .NET 8.0.14 (8.0.1425.11118), X64 RyuJIT AVX-512F+CD+BW+DQ+VL
  DefaultJob : .NET 8.0.14 (8.0.1425.11118), X64 RyuJIT AVX-512F+CD+BW+DQ+VL


```
| Method        | Format | Mean       | Error    | StdDev   | Gen0        | Gen1       | Gen2       | Allocated      |
|-------------- |------- |-----------:|---------:|---------:|------------:|-----------:|-----------:|---------------:|
| **SystemDrawing** | **Jpeg**   | **1,693.5 ms** | **33.17 ms** | **48.62 ms** |           **-** |          **-** |          **-** |      **129.79 KB** |
| SkiaSharp     | Jpeg   | 2,060.0 ms | 41.03 ms | 69.67 ms |           - |          - |          - |      148.54 KB |
| LibTiff       | Jpeg   |         NA |       NA |       NA |          NA |         NA |         NA |             NA |
| MagickNet     | Jpeg   | 2,583.0 ms | 48.92 ms | 48.04 ms |  17000.0000 | 17000.0000 | 17000.0000 |  3397504.87 KB |
| Aspose        | Jpeg   | 5,522.2 ms | 97.61 ms | 91.30 ms | 193000.0000 | 34000.0000 | 23000.0000 | 13410674.77 KB |
| ImageSharp    | Jpeg   | 1,583.2 ms | 30.87 ms | 41.21 ms |   8000.0000 |  8000.0000 |  8000.0000 |   851390.78 KB |
| **SystemDrawing** | **Tiff**   |   **171.3 ms** |  **3.41 ms** |  **5.31 ms** |           **-** |          **-** |          **-** |          **27 KB** |
| SkiaSharp     | Tiff   |         NA |       NA |       NA |          NA |         NA |         NA |             NA |
| LibTiff       | Tiff   |   125.5 ms |  2.51 ms |  4.39 ms |   1200.0000 |  1000.0000 |          - |    24989.46 KB |
| MagickNet     | Tiff   | 1,852.0 ms | 36.11 ms | 66.02 ms |  12000.0000 | 12000.0000 | 12000.0000 |  3397473.88 KB |
| Aspose        | Tiff   | 1,647.5 ms | 32.73 ms | 53.77 ms |  18000.0000 | 17000.0000 | 16000.0000 |  7043952.01 KB |
| ImageSharp    | Tiff   | 1,481.0 ms | 29.53 ms | 39.42 ms |  20000.0000 | 16000.0000 | 11000.0000 |  1024610.35 KB |
| **SystemDrawing** | **WebP**   |         **NA** |       **NA** |       **NA** |          **NA** |         **NA** |         **NA** |             **NA** |
| SkiaSharp     | WebP   | 1,966.6 ms | 38.08 ms | 57.00 ms |           - |          - |          - |      148.54 KB |
| LibTiff       | WebP   |         NA |       NA |       NA |          NA |         NA |         NA |             NA |
| MagickNet     | WebP   | 3,084.7 ms | 52.61 ms | 49.21 ms |  20000.0000 | 20000.0000 | 20000.0000 |  3397486.39 KB |
| Aspose        | WebP   |         NA |       NA |       NA |          NA |         NA |         NA |             NA |
| ImageSharp    | WebP   | 3,608.0 ms | 70.87 ms | 72.78 ms |  68000.0000 | 66000.0000 | 62000.0000 |   963783.64 KB |

Benchmarks with issues:
  ToBinaryMultiThreadBenchmarks.LibTiff: DefaultJob [Format=Jpeg]
  ToBinaryMultiThreadBenchmarks.SkiaSharp: DefaultJob [Format=Tiff]
  ToBinaryMultiThreadBenchmarks.SystemDrawing: DefaultJob [Format=WebP]
  ToBinaryMultiThreadBenchmarks.LibTiff: DefaultJob [Format=WebP]
  ToBinaryMultiThreadBenchmarks.Aspose: DefaultJob [Format=WebP]
