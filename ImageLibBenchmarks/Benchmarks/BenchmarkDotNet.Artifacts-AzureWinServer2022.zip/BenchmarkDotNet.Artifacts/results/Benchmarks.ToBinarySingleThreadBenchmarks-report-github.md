```

BenchmarkDotNet v0.14.0, Windows 10 (10.0.20348.3270) (Hyper-V)
Intel Xeon Platinum 8171M CPU 2.60GHz, 1 CPU, 16 logical and 8 physical cores
.NET SDK 8.0.407
  [Host]     : .NET 8.0.14 (8.0.1425.11118), X64 RyuJIT AVX-512F+CD+BW+DQ+VL
  DefaultJob : .NET 8.0.14 (8.0.1425.11118), X64 RyuJIT AVX-512F+CD+BW+DQ+VL


```
| Method        | Format | Mean       | Error     | StdDev    | Median     | Gen0      | Gen1      | Gen2      | Allocated   |
|-------------- |------- |-----------:|----------:|----------:|-----------:|----------:|----------:|----------:|------------:|
| **SystemDrawing** | **Jpeg**   | **112.250 ms** | **2.2040 ms** | **2.8658 ms** | **110.994 ms** |         **-** |         **-** |         **-** |      **1384 B** |
| SkiaSharp     | Jpeg   | 145.346 ms | 1.0026 ms | 0.8888 ms | 145.703 ms |         - |         - |         - |      1596 B |
| LibTiff       | Jpeg   |         NA |        NA |        NA |         NA |        NA |        NA |        NA |          NA |
| MagickNet     | Jpeg   | 181.305 ms | 3.5409 ms | 6.5632 ms | 177.651 ms |  333.3333 |  333.3333 |  333.3333 |  34790157 B |
| Aspose        | Jpeg   | 337.896 ms | 1.9173 ms | 1.6011 ms | 338.384 ms | 2000.0000 | 1000.0000 | 1000.0000 | 137316376 B |
| ImageSharp    | Jpeg   | 113.815 ms | 2.2692 ms | 2.0116 ms | 114.622 ms |  400.0000 |  400.0000 |  400.0000 |   8721990 B |
| **SystemDrawing** | **Tiff**   |  **10.884 ms** | **0.0337 ms** | **0.0298 ms** |  **10.876 ms** |         **-** |         **-** |         **-** |       **262 B** |
| SkiaSharp     | Tiff   |         NA |        NA |        NA |         NA |        NA |        NA |        NA |          NA |
| LibTiff       | Tiff   |   8.506 ms | 0.0209 ms | 0.0174 ms |   8.504 ms |         - |         - |         - |    255878 B |
| MagickNet     | Tiff   | 121.152 ms | 1.1719 ms | 1.3025 ms | 120.716 ms |  250.0000 |  250.0000 |  250.0000 |  34790098 B |
| Aspose        | Tiff   | 103.749 ms | 0.9193 ms | 0.7177 ms | 103.373 ms | 1000.0000 | 1000.0000 | 1000.0000 |  72120838 B |
| ImageSharp    | Tiff   |  91.888 ms | 0.5606 ms | 0.4681 ms |  91.653 ms |  428.5714 |  428.5714 |  428.5714 |  10493097 B |
| **SystemDrawing** | **WebP**   |         **NA** |        **NA** |        **NA** |         **NA** |        **NA** |        **NA** |        **NA** |          **NA** |
| SkiaSharp     | WebP   | 132.595 ms | 0.9969 ms | 0.8324 ms | 132.334 ms |         - |         - |         - |      1596 B |
| LibTiff       | WebP   |         NA |        NA |        NA |         NA |        NA |        NA |        NA |          NA |
| MagickNet     | WebP   | 209.797 ms | 4.1611 ms | 6.9522 ms | 205.163 ms |  333.3333 |  333.3333 |  333.3333 |  34790157 B |
| Aspose        | WebP   |         NA |        NA |        NA |         NA |        NA |        NA |        NA |          NA |
| ImageSharp    | WebP   | 230.590 ms | 3.4756 ms | 3.2511 ms | 229.556 ms | 1000.0000 | 1000.0000 | 1000.0000 |   9858899 B |

Benchmarks with issues:
  ToBinarySingleThreadBenchmarks.LibTiff: DefaultJob [Format=Jpeg]
  ToBinarySingleThreadBenchmarks.SkiaSharp: DefaultJob [Format=Tiff]
  ToBinarySingleThreadBenchmarks.SystemDrawing: DefaultJob [Format=WebP]
  ToBinarySingleThreadBenchmarks.LibTiff: DefaultJob [Format=WebP]
  ToBinarySingleThreadBenchmarks.Aspose: DefaultJob [Format=WebP]
