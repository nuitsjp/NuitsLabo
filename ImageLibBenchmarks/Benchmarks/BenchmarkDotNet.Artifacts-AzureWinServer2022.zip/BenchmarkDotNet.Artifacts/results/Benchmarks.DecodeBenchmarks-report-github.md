```

BenchmarkDotNet v0.14.0, Windows 10 (10.0.20348.3270) (Hyper-V)
Intel Xeon Platinum 8171M CPU 2.60GHz, 1 CPU, 16 logical and 8 physical cores
.NET SDK 8.0.407
  [Host]     : .NET 8.0.14 (8.0.1425.11118), X64 RyuJIT AVX-512F+CD+BW+DQ+VL
  DefaultJob : .NET 8.0.14 (8.0.1425.11118), X64 RyuJIT AVX-512F+CD+BW+DQ+VL


```
| Method        | Format | Mean      | Error    | StdDev   | Gen0      | Gen1      | Gen2      | Allocated |
|-------------- |------- |----------:|---------:|---------:|----------:|----------:|----------:|----------:|
| **SystemDrawing** | **Jpeg**   |  **45.14 ms** | **0.890 ms** | **0.832 ms** |         **-** |         **-** |         **-** |     **201 B** |
| SkiaSharp     | Jpeg   |  86.46 ms | 1.660 ms | 1.630 ms |         - |         - |         - |     363 B |
| ImageSharp    | Jpeg   |  51.44 ms | 1.014 ms | 1.518 ms |         - |         - |         - |   20372 B |
| **SystemDrawing** | **Tiff**   |  **10.27 ms** | **0.126 ms** | **0.112 ms** |         **-** |         **-** |         **-** |     **174 B** |
| SkiaSharp     | Tiff   |        NA |       NA |       NA |        NA |        NA |        NA |        NA |
| ImageSharp    | Tiff   |  27.70 ms | 0.530 ms | 0.611 ms |   93.7500 |   31.2500 |         - | 1793526 B |
| **SystemDrawing** | **WebP**   |        **NA** |       **NA** |       **NA** |        **NA** |        **NA** |        **NA** |        **NA** |
| SkiaSharp     | WebP   |  71.55 ms | 1.427 ms | 1.752 ms |         - |         - |         - |     346 B |
| ImageSharp    | WebP   | 171.34 ms | 2.566 ms | 2.520 ms | 1000.0000 | 1000.0000 | 1000.0000 | 1159197 B |

Benchmarks with issues:
  DecodeBenchmarks.SkiaSharp: DefaultJob [Format=Tiff]
  DecodeBenchmarks.SystemDrawing: DefaultJob [Format=WebP]
