```

BenchmarkDotNet v0.14.0, Windows 11 (10.0.26100.3476) (Hyper-V)
INTEL XEON PLATINUM 8573C, 1 CPU, 8 logical and 4 physical cores
  [Host]               : .NET Framework 4.8.1 (4.8.9290.0), X64 RyuJIT VectorSize=256
  .NET 8.0             : .NET 8.0.14 (8.0.1425.11118), X64 RyuJIT AVX-512F+CD+BW+DQ+VL+VBMI
  .NET Framework 4.8.1 : .NET Framework 4.8.1 (4.8.9290.0), X64 RyuJIT VectorSize=256


```
| Method        | Job                  | Runtime              | Format | Mean       | Error     | StdDev    | Gen0     | Gen1     | Gen2     | Allocated  |
|-------------- |--------------------- |--------------------- |------- |-----------:|----------:|----------:|---------:|---------:|---------:|-----------:|
| **SystemDrawing** | **.NET 8.0**             | **.NET 8.0**             | **Jpeg**   |  **65.814 ms** | **0.2181 ms** | **0.2040 ms** |        **-** |        **-** |        **-** |     **1348 B** |
| SkiaSharp     | .NET 8.0             | .NET 8.0             | Jpeg   |  72.015 ms | 0.2832 ms | 0.2649 ms |        - |        - |        - |     1553 B |
| LibTiff       | .NET 8.0             | .NET 8.0             | Jpeg   |         NA |        NA |        NA |       NA |       NA |       NA |         NA |
| MagickNet     | .NET 8.0             | .NET 8.0             | Jpeg   |  99.724 ms | 0.2433 ms | 0.1899 ms | 400.0000 | 400.0000 | 400.0000 | 34790130 B |
| SystemDrawing | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Jpeg   |  62.599 ms | 0.4672 ms | 0.4370 ms |        - |        - |        - |   473088 B |
| SkiaSharp     | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Jpeg   |  72.834 ms | 0.1089 ms | 0.1019 ms |        - |        - |        - |     2341 B |
| LibTiff       | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Jpeg   |         NA |        NA |        NA |       NA |       NA |       NA |         NA |
| MagickNet     | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Jpeg   | 104.188 ms | 0.3392 ms | 0.3173 ms | 400.0000 | 400.0000 | 400.0000 | 34794040 B |
| **SystemDrawing** | **.NET 8.0**             | **.NET 8.0**             | **Tiff**   |  **27.218 ms** | **0.0332 ms** | **0.0277 ms** |        **-** |        **-** |        **-** |      **268 B** |
| SkiaSharp     | .NET 8.0             | .NET 8.0             | Tiff   |         NA |        NA |        NA |       NA |       NA |       NA |         NA |
| LibTiff       | .NET 8.0             | .NET 8.0             | Tiff   |   4.753 ms | 0.0093 ms | 0.0082 ms |        - |        - |        - |   255875 B |
| MagickNet     | .NET 8.0             | .NET 8.0             | Tiff   |  69.552 ms | 0.2545 ms | 0.2256 ms | 571.4286 | 571.4286 | 571.4286 | 34790162 B |
| SystemDrawing | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Tiff   |  27.961 ms | 0.0814 ms | 0.0761 ms |        - |        - |        - |   138392 B |
| SkiaSharp     | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Tiff   |         NA |        NA |        NA |       NA |       NA |       NA |         NA |
| LibTiff       | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Tiff   |   6.164 ms | 0.0151 ms | 0.0134 ms |  39.0625 |   7.8125 |        - |   256411 B |
| MagickNet     | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Tiff   |  74.848 ms | 0.2414 ms | 0.2140 ms | 428.5714 | 428.5714 | 428.5714 | 34793234 B |
| **SystemDrawing** | **.NET 8.0**             | **.NET 8.0**             | **WebP**   |         **NA** |        **NA** |        **NA** |       **NA** |       **NA** |       **NA** |         **NA** |
| SkiaSharp     | .NET 8.0             | .NET 8.0             | WebP   |  72.003 ms | 0.2383 ms | 0.2229 ms |        - |        - |        - |     1553 B |
| LibTiff       | .NET 8.0             | .NET 8.0             | WebP   |         NA |        NA |        NA |       NA |       NA |       NA |         NA |
| MagickNet     | .NET 8.0             | .NET 8.0             | WebP   | 110.433 ms | 1.1008 ms | 1.0297 ms | 400.0000 | 400.0000 | 400.0000 | 34790130 B |
| SystemDrawing | .NET Framework 4.8.1 | .NET Framework 4.8.1 | WebP   |         NA |        NA |        NA |       NA |       NA |       NA |         NA |
| SkiaSharp     | .NET Framework 4.8.1 | .NET Framework 4.8.1 | WebP   |  74.422 ms | 0.2608 ms | 0.2439 ms |        - |        - |        - |     2341 B |
| LibTiff       | .NET Framework 4.8.1 | .NET Framework 4.8.1 | WebP   |         NA |        NA |        NA |       NA |       NA |       NA |         NA |
| MagickNet     | .NET Framework 4.8.1 | .NET Framework 4.8.1 | WebP   | 114.243 ms | 0.3366 ms | 0.3148 ms | 400.0000 | 400.0000 | 400.0000 | 34794040 B |

Benchmarks with issues:
  ToBinarySingleThreadBenchmarks.LibTiff: .NET 8.0(Runtime=.NET 8.0) [Format=Jpeg]
  ToBinarySingleThreadBenchmarks.LibTiff: .NET Framework 4.8.1(Runtime=.NET Framework 4.8.1) [Format=Jpeg]
  ToBinarySingleThreadBenchmarks.SkiaSharp: .NET 8.0(Runtime=.NET 8.0) [Format=Tiff]
  ToBinarySingleThreadBenchmarks.SkiaSharp: .NET Framework 4.8.1(Runtime=.NET Framework 4.8.1) [Format=Tiff]
  ToBinarySingleThreadBenchmarks.SystemDrawing: .NET 8.0(Runtime=.NET 8.0) [Format=WebP]
  ToBinarySingleThreadBenchmarks.LibTiff: .NET 8.0(Runtime=.NET 8.0) [Format=WebP]
  ToBinarySingleThreadBenchmarks.SystemDrawing: .NET Framework 4.8.1(Runtime=.NET Framework 4.8.1) [Format=WebP]
  ToBinarySingleThreadBenchmarks.LibTiff: .NET Framework 4.8.1(Runtime=.NET Framework 4.8.1) [Format=WebP]
