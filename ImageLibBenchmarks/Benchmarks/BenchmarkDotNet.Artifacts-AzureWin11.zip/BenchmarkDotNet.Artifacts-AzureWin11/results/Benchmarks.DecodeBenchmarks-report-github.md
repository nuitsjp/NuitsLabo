```

BenchmarkDotNet v0.14.0, Windows 11 (10.0.26100.3476) (Hyper-V)
INTEL XEON PLATINUM 8573C, 1 CPU, 8 logical and 4 physical cores
  [Host]               : .NET Framework 4.8.1 (4.8.9290.0), X64 RyuJIT VectorSize=256
  .NET 8.0             : .NET 8.0.14 (8.0.1425.11118), X64 RyuJIT AVX-512F+CD+BW+DQ+VL+VBMI
  .NET Framework 4.8.1 : .NET Framework 4.8.1 (4.8.9290.0), X64 RyuJIT VectorSize=256


```
| Method        | Job                  | Runtime              | Format | Mean         | Error      | StdDev     | Gen0    | Gen1   | Allocated |
|-------------- |--------------------- |--------------------- |------- |-------------:|-----------:|-----------:|--------:|-------:|----------:|
| **SystemDrawing** | **.NET 8.0**             | **.NET 8.0**             | **Jpeg**   | **19,053.20 μs** |  **93.379 μs** |  **82.778 μs** |       **-** |      **-** |     **180 B** |
| SkiaSharp     | .NET 8.0             | .NET 8.0             | Jpeg   | 38,099.48 μs | 156.576 μs | 138.800 μs |       - |      - |     325 B |
| LibTiff       | .NET 8.0             | .NET 8.0             | Jpeg   |    114.95 μs |   2.296 μs |   4.082 μs |       - |      - |    8248 B |
| MagickNet     | .NET 8.0             | .NET 8.0             | Jpeg   | 48,932.85 μs | 294.417 μs | 245.852 μs |       - |      - |    3364 B |
| SystemDrawing | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Jpeg   | 19,267.72 μs |  77.756 μs |  72.733 μs | 62.5000 |      - |  472067 B |
| SkiaSharp     | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Jpeg   | 38,425.28 μs | 234.698 μs | 219.536 μs |       - |      - |         - |
| LibTiff       | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Jpeg   |    114.43 μs |   2.272 μs |   4.038 μs |  1.3428 |      - |    8690 B |
| MagickNet     | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Jpeg   | 49,030.05 μs | 261.861 μs | 244.945 μs |       - |      - |    3724 B |
| **SystemDrawing** | **.NET 8.0**             | **.NET 8.0**             | **Tiff**   | **26,565.05 μs** |  **58.924 μs** |  **55.118 μs** |       **-** |      **-** |     **180 B** |
| SkiaSharp     | .NET 8.0             | .NET 8.0             | Tiff   |           NA |         NA |         NA |      NA |     NA |        NA |
| LibTiff       | .NET 8.0             | .NET 8.0             | Tiff   |     31.10 μs |   0.615 μs |   0.632 μs |  1.6174 | 0.0610 |  137400 B |
| MagickNet     | .NET 8.0             | .NET 8.0             | Tiff   | 20,397.84 μs | 112.446 μs |  99.681 μs |       - |      - |    3340 B |
| SystemDrawing | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Tiff   | 27,174.84 μs |  48.831 μs |  43.287 μs |       - |      - |  138392 B |
| SkiaSharp     | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Tiff   |           NA |         NA |         NA |      NA |     NA |        NA |
| LibTiff       | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Tiff   |     49.78 μs |   0.341 μs |   0.319 μs | 21.8506 | 0.8545 |  137830 B |
| MagickNet     | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Tiff   | 20,355.94 μs | 134.831 μs | 126.121 μs |       - |      - |    3584 B |
| **SystemDrawing** | **.NET 8.0**             | **.NET 8.0**             | **WebP**   |           **NA** |         **NA** |         **NA** |      **NA** |     **NA** |        **NA** |
| SkiaSharp     | .NET 8.0             | .NET 8.0             | WebP   | 39,218.06 μs | 183.616 μs | 171.754 μs |       - |      - |     327 B |
| LibTiff       | .NET 8.0             | .NET 8.0             | WebP   |    114.31 μs |   2.274 μs |   3.404 μs |       - |      - |    8248 B |
| MagickNet     | .NET 8.0             | .NET 8.0             | WebP   | 58,939.65 μs | 121.939 μs | 114.062 μs |       - |      - |    3372 B |
| SystemDrawing | .NET Framework 4.8.1 | .NET Framework 4.8.1 | WebP   |           NA |         NA |         NA |      NA |     NA |        NA |
| SkiaSharp     | .NET Framework 4.8.1 | .NET Framework 4.8.1 | WebP   | 39,108.02 μs | 136.844 μs | 121.309 μs |       - |      - |         - |
| LibTiff       | .NET Framework 4.8.1 | .NET Framework 4.8.1 | WebP   |    115.67 μs |   2.268 μs |   3.662 μs |  1.3428 |      - |    8690 B |
| MagickNet     | .NET Framework 4.8.1 | .NET Framework 4.8.1 | WebP   | 58,880.48 μs | 179.190 μs | 167.615 μs |       - |      - |    3641 B |

Benchmarks with issues:
  DecodeBenchmarks.SkiaSharp: .NET 8.0(Runtime=.NET 8.0) [Format=Tiff]
  DecodeBenchmarks.SkiaSharp: .NET Framework 4.8.1(Runtime=.NET Framework 4.8.1) [Format=Tiff]
  DecodeBenchmarks.SystemDrawing: .NET 8.0(Runtime=.NET 8.0) [Format=WebP]
  DecodeBenchmarks.SystemDrawing: .NET Framework 4.8.1(Runtime=.NET Framework 4.8.1) [Format=WebP]
