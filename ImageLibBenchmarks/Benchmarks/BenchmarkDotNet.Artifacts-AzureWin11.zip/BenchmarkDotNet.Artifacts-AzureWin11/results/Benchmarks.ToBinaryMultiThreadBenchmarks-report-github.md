```

BenchmarkDotNet v0.14.0, Windows 11 (10.0.26100.3476) (Hyper-V)
INTEL XEON PLATINUM 8573C, 1 CPU, 8 logical and 4 physical cores
  [Host]               : .NET Framework 4.8.1 (4.8.9290.0), X64 RyuJIT VectorSize=256
  .NET 8.0             : .NET 8.0.14 (8.0.1425.11118), X64 RyuJIT AVX-512F+CD+BW+DQ+VL+VBMI
  .NET Framework 4.8.1 : .NET Framework 4.8.1 (4.8.9290.0), X64 RyuJIT VectorSize=256


```
| Method        | Job                  | Runtime              | Format | Mean        | Error     | StdDev    | Gen0       | Gen1       | Gen2       | Allocated     |
|-------------- |--------------------- |--------------------- |------- |------------:|----------:|----------:|-----------:|-----------:|-----------:|--------------:|
| **SystemDrawing** | **.NET 8.0**             | **.NET 8.0**             | **Jpeg**   | **1,293.94 ms** | **20.560 ms** | **20.193 ms** |          **-** |          **-** |          **-** |     **129.79 KB** |
| SkiaSharp     | .NET 8.0             | .NET 8.0             | Jpeg   | 1,589.69 ms | 31.364 ms | 30.803 ms |          - |          - |          - |     148.54 KB |
| LibTiff       | .NET 8.0             | .NET 8.0             | Jpeg   |          NA |        NA |        NA |         NA |         NA |         NA |            NA |
| MagickNet     | .NET 8.0             | .NET 8.0             | Jpeg   | 2,024.21 ms | 17.505 ms | 15.517 ms | 15000.0000 | 15000.0000 | 15000.0000 | 3397549.06 KB |
| SystemDrawing | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Jpeg   | 1,764.31 ms | 35.058 ms | 34.431 ms | 12000.0000 |          - |          - |   73880.56 KB |
| SkiaSharp     | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Jpeg   | 2,040.86 ms | 29.190 ms | 25.876 ms |          - |          - |          - |        232 KB |
| LibTiff       | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Jpeg   |          NA |        NA |        NA |         NA |         NA |         NA |            NA |
| MagickNet     | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Jpeg   | 2,932.00 ms | 57.690 ms | 80.874 ms |  9000.0000 |  9000.0000 |  9000.0000 | 3397739.33 KB |
| **SystemDrawing** | **.NET 8.0**             | **.NET 8.0**             | **Tiff**   |   **791.29 ms** | **12.703 ms** | **11.883 ms** |          **-** |          **-** |          **-** |      **27.45 KB** |
| SkiaSharp     | .NET 8.0             | .NET 8.0             | Tiff   |          NA |        NA |        NA |         NA |         NA |         NA |            NA |
| LibTiff       | .NET 8.0             | .NET 8.0             | Tiff   |    90.33 ms |  1.440 ms |  1.601 ms |   200.0000 |          - |          - |   24989.41 KB |
| MagickNet     | .NET 8.0             | .NET 8.0             | Tiff   | 1,391.76 ms | 19.511 ms | 34.172 ms | 13000.0000 | 13000.0000 | 13000.0000 | 3397496.82 KB |
| SystemDrawing | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Tiff   |   809.79 ms | 15.540 ms | 15.262 ms |  2000.0000 |          - |          - |   13961.84 KB |
| SkiaSharp     | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Tiff   |          NA |        NA |        NA |         NA |         NA |         NA |            NA |
| LibTiff       | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Tiff   |   143.08 ms |  0.830 ms |  0.776 ms |  4000.0000 |  2000.0000 |          - |   25480.32 KB |
| MagickNet     | .NET Framework 4.8.1 | .NET Framework 4.8.1 | Tiff   | 2,156.11 ms | 42.957 ms | 65.600 ms | 15000.0000 | 15000.0000 | 15000.0000 | 3397759.81 KB |
| **SystemDrawing** | **.NET 8.0**             | **.NET 8.0**             | **WebP**   |          **NA** |        **NA** |        **NA** |         **NA** |         **NA** |         **NA** |            **NA** |
| SkiaSharp     | .NET 8.0             | .NET 8.0             | WebP   | 1,520.28 ms | 17.524 ms | 16.392 ms |          - |          - |          - |     148.54 KB |
| LibTiff       | .NET 8.0             | .NET 8.0             | WebP   |          NA |        NA |        NA |         NA |         NA |         NA |            NA |
| MagickNet     | .NET 8.0             | .NET 8.0             | WebP   | 2,213.55 ms | 21.564 ms | 19.116 ms | 18000.0000 | 18000.0000 | 18000.0000 | 3397493.53 KB |
| SystemDrawing | .NET Framework 4.8.1 | .NET Framework 4.8.1 | WebP   |          NA |        NA |        NA |         NA |         NA |         NA |            NA |
| SkiaSharp     | .NET Framework 4.8.1 | .NET Framework 4.8.1 | WebP   | 2,010.17 ms | 19.143 ms | 17.907 ms |          - |          - |          - |        232 KB |
| LibTiff       | .NET Framework 4.8.1 | .NET Framework 4.8.1 | WebP   |          NA |        NA |        NA |         NA |         NA |         NA |            NA |
| MagickNet     | .NET Framework 4.8.1 | .NET Framework 4.8.1 | WebP   | 3,192.27 ms | 60.247 ms | 82.467 ms | 19000.0000 | 19000.0000 | 19000.0000 | 3397909.35 KB |

Benchmarks with issues:
  ToBinaryMultiThreadBenchmarks.LibTiff: .NET 8.0(Runtime=.NET 8.0) [Format=Jpeg]
  ToBinaryMultiThreadBenchmarks.LibTiff: .NET Framework 4.8.1(Runtime=.NET Framework 4.8.1) [Format=Jpeg]
  ToBinaryMultiThreadBenchmarks.SkiaSharp: .NET 8.0(Runtime=.NET 8.0) [Format=Tiff]
  ToBinaryMultiThreadBenchmarks.SkiaSharp: .NET Framework 4.8.1(Runtime=.NET Framework 4.8.1) [Format=Tiff]
  ToBinaryMultiThreadBenchmarks.SystemDrawing: .NET 8.0(Runtime=.NET 8.0) [Format=WebP]
  ToBinaryMultiThreadBenchmarks.LibTiff: .NET 8.0(Runtime=.NET 8.0) [Format=WebP]
  ToBinaryMultiThreadBenchmarks.SystemDrawing: .NET Framework 4.8.1(Runtime=.NET Framework 4.8.1) [Format=WebP]
  ToBinaryMultiThreadBenchmarks.LibTiff: .NET Framework 4.8.1(Runtime=.NET Framework 4.8.1) [Format=WebP]
